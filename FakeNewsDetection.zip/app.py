from flask import Flask, request, render_template
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

# Load the trained model and vectorizer
with open('./Model/random_forest_model.pkl', 'rb') as model_file:
    random_forest_model = pickle.load(model_file)

with open('./Model/tfidf_vectorizer.pkl', 'rb') as vectorizer_file:
    vectorizer = pickle.load(vectorizer_file)

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        stemmer = PorterStemmer()
        title = request.form['title']
        description = request.form['description']
        combined_text = title + " " + description

        combined_text = combined_text.lower()
        tokens = nltk.word_tokenize(combined_text)
        stemmed_text = ' '.join([stemmer.stem(token) for token in tokens])

        vectorized_text = vectorizer.transform([stemmed_text])
        prediction = random_forest_model.predict(vectorized_text)

        result = "Berita Real" if prediction[0] == 1 else "Berita Fake"
        return render_template('index.html', prediction_text=f'The news is {result}')
    except Exception as e:
        return str(e)  # For debugging

if __name__ == '__main__':
    app.run(debug=True)
