Prediction Fake News - Project Data Mining
